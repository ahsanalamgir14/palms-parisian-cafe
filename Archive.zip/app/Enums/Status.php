<?php

namespace App\Enums;

interface Status
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
