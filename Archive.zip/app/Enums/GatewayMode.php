<?php

namespace App\Enums;

interface GatewayMode
{
    const SANDBOX = 5;
    const LIVE    = 10;
}
