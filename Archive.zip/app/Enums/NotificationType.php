<?php

namespace App\Enums;


interface NotificationType
{
    const SINGLE = 5;
    const ALL    = 10;
}